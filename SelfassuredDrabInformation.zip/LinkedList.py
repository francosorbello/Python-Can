##Juan Codilupi
##N° de leg : 12083
##codiluppi@gmail.com

class LinkedList :
  def __init__(self):
    
    self.head = None
  
  
class Node :
  def __init__(self):
    
  
    self.value = None
    self.nextNode = None


def imprimir (LinkedList):
	z=LinkedList.head
	if z == None:
		print("None")
	else:
		i=0
		while z != None:
			print("Plato Nº"+str(i)+":"+str(z.value))
			z=z.nextNode
			i=i+1
			
def add (LinkedList , element ):  
  Newnode = Node()  
  Newnode.value = element  
  Newnode.nextNode = LinkedList.head     
  LinkedList.head = Newnode
  
  
def search (LinkedList , element):  
  
  nada = 0  
  posicion = 0  
  currentNode = LinkedList.head  
  
  while currentNode != None : 
                                
    
    if currentNode.value == element :  
      return posicion
      
      nada = 1 
     
    posicion = posicion + 1
    currentNode = currentNode.nextNode 
     
  if nada == 0 : 
    return None

def insert (LinkedList , element , position ):  
  
  
  Newnode = Node()  
  Newnode.value = element 
  currentNode = LinkedList.head  
  
  tam = length(LinkedList) 
  
  if position < 0 or position > tam :
    return None
  else :
    count = 0  
    if position ==  0 : 
      
      Newnode.nextNode = currentNode  
      LinkedList.head = Newnode 
      return 0
    else :
    
      while count <= position - 1 :   
    
        if count == position - 1    :
          Newnode.nextNode = currentNode.nextNode
          currentNode.nextNode = Newnode
          return count+1
          break
        currentNode = currentNode.nextNode
    
        count = count + 1
        
def length (LinkedList ):
  if LinkedList.head == None :
    return 0 
    
  currentNode = LinkedList.head
  count = 0
  while currentNode != None :
    count = count + 1 
    currentNode = currentNode.nextNode
    
  return count

def delete (Lista, element ):#O(f) = n 
  if Lista.head==None:
    return None 
  currentNode = Lista.head  #OE = 1 
  
  if currentNode.value == element : #OE = 1 
    Lista.head = currentNode.nextNode  ##me fijo si el elemento esta en la cabecera 
  else :
    
    while currentNode.value != element :   #recorro la lista
      prevNode=currentNode  ##guardo el anterior
      currentNode=currentNode.nextNode ##y tambien guardo donde esta el elemnto
      if currentNode==None: ## si no esta el  elemento devuelvo -1 
        return None
    #encontrado
   
    prevNode.nextNode=currentNode.nextNode ## el anterior apunta al nodo siguiente de donde esta el elemnto
    
def update (Lista , element , position):
  currentNode = Lista.head
  pos = 0
  tam = length(Lista)
  if position < 0 or position > tam :
    return None
  else :
    
    while currentNode != None :
    
      if pos == position :
        currentNode.value = element
        return pos
      else : 
      
        pos = pos + 1 
        currentNode=  currentNode.nextNode
      
     
 
def access (Lista , position ):
  currentNode = Lista.head
  pos = 0
  tam = length(Lista)
  if position < 0 or position > tam :
    return None
  else :
    
    while currentNode != None :
    
      if pos == position :
        return currentNode.value
      else : 
      
        pos = pos + 1 
        currentNode=  currentNode.nextNode
        
        
def enqueue(LinkedList,element):
  
        
    
  NewNode = Node()
  NewNode.value = element
  NewNode.nextNode = None
  
  if LinkedList.head == None:
    ##si la cabecera esta vacia coloco el nuevo nodo ahi 
   
    LinkedList.head = NewNode
  else : 
     
    currentNode = LinkedList.head
    while currentNode != None :
      
      if currentNode.nextNode == None :  ##si no , recoorro la lista hasta , llego al nodo que apunta nada (al ultimo ) y hago que el mismo apunte al nuevo nodo
        currentNode.nextNode = NewNode 
        
        break
      currentNode = currentNode.nextNode
       
def dequeue(LinkedList):
  aux=LinkedList.head
  delete(LinkedList,LinkedList.head.value)
  return(aux.value)

def push(LinkedList,element):
 
 
  NewNode = Node()
  NewNode.value = element
  NewNode.nextNode = LinkedList.head
  LinkedList.head = NewNode
    
def pop(LinkedList):
    
  element = LinkedList.head.value
  delete(LinkedList, LinkedList.head.value)
  return element 
