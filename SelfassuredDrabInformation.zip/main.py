from LinkedList import *
from array import array

#VERSION 11:05 PM

#CLASES#


class Restaurante:
	semana = None
	Rotador = None


class semana:
	vec = [0, 0, 0, 0, 0, 0, 0]


class Rotador:
	def __init__(self):
		self.L = LinkedList()


class pedidos:
	def __init__(self):

		self.L = LinkedList()


salir = -1

##########################
## CARGO UN NUEVO PEDIDO##
##########################


def nuevo_pedido():
	salir = -1
	newpedido = pedidos()
	i = 0
	while salir != 0:
		pedi = input("\n Ingrese plato: ")
		enqueue(newpedido.L, pedi)
		#print (newpedido.L.head.value)
		i = i + 1
		salir = int(input("\n 0. Salir \n 1. Cargar otro plato\n\nOpción: "))
	return newpedido


##########################
## CADA VEZ QUE SE INICIA EL PROGRAMA CREA UN NUEVO RESTORANT Y UNA NUEVA SEMANA##
##########################

newRestaurante = Restaurante()
newRestaurante.semana = semana()

##########################
## SE INICIA UN NUEVO DIA##
##########################


def new_dia(contador, cantidad_semana):

	new_rotador = Rotador()

	salir = -1
	if contador == 0:
		print("\nBienvenido al dia Lunes\n", )
	elif contador == 1:
		print("\nBienvenido al dia Martes\n", )
	elif contador == 2:
		print("\nBienvenido al dia Miercoles\n", )
	elif contador == 3:
		print("\nBienvenido al dia Jueves\n", )
	elif contador == 4:
		print("\nBienvenido al dia Viernes\n", )
	elif contador == 5:
		print("\nBienvenido al dia Sabado\n", )
	elif contador == 6:
		print("\nBienvenido al dia Domingo\n", )

	while salir != 0:

		salir = int(
		    input(
		        "\nMarque la opcion deseada\n\n 0. Salir \n 1. Nuevo pedido \n 2. Cantidad de hoy dia \n 3. Primer plato de la comanda \n 4. Sacar pedido de Rotador \n 5. Segundo plato de la comanda Plato\n\n Opcion: "
		    ))

		if salir == 1:
			pedidox = nuevo_pedido()
			enqueue(new_rotador.L, pedidox)
			newRestaurante.Rotador = new_rotador

		elif salir == 2:

			if len(cantidad_semana.vec) == 0:
				print("\n No ha sacado ningun pedido hoy")
			else:
				print("\n La cantidad de pedidos que lleva hoy dia es ",
				      cantidad_semana.vec[contador])

		elif salir == 0:

			newRestaurante.semana.vec.append(length(new_rotador.L))

		elif salir == 3:
			if new_rotador.L.head == None:
				print("\n No hay platos para mostrar")
			else:
				print("\nPrimer plato de la comanda: ",
				      new_rotador.L.head.value.L.head.value
				      )  #muestra el plato actual

		elif salir == 4:
			if new_rotador.L.head != None:
				cantidad_semana.vec[
				    contador] = cantidad_semana.vec[contador] + 1
				imprimir(new_rotador.L.head.value.L)
				dequeue(new_rotador.L)  #saco plato
			else:
				print("\n No hay pedidos para sacar")

		elif salir == 5:
			if new_rotador.L.head == None:
				print("\nNo hay siguiente plato")
			elif new_rotador.L.head.value.L.head.nextNode != None:
				print("\nSegundo plato de la comanda",
				      new_rotador.L.head.value.L.head.nextNode.value)


##########################
## FUNCION QUE DEVUELVE EL NOMBRE DEL DIA##
##########################


def comparar(n):
	if n == 1:
		print("El dia con menos pedidos es el Lunes")
	elif n == 2:
		print("El dia con menos pedidos es el Martes")
	elif n == 3:
		print("El dia con menos pedidos es el Miercoles")
	elif n == 4:
		print("El dia con menos pedidos es el Jueves")
	elif n == 5:
		print("El dia con menos pedidos es el Viernes")
	elif n == 6:
		print("El dia con menos pedidos es el Sabado")
	elif n == 7:
		print("El dia con menos pedidos es el Domingo")


##########################
## MENU PRINCIPAL##
##########################


def main():
	salir = -1
	contador = 0
	while salir != 0:
		salir = int(
		    input(
		        "\n Marque la opcion deseada \n\n 0. Salir del programa\n 1. Nuevo día\n 2. Consultar día con menos pedidos \n\n Opcion: "
		    ))
		if salir != 0 and salir != 1 and salir != 2:
			print("\nOpcion incorrecta")
		elif salir == 1:
			cantidad_semana = semana()
			new_dia(contador, cantidad_semana)
			contador = contador + 1
			if contador == 8:
				contador = 0
		elif salir == 2:
			if len(newRestaurante.semana.vec) == 0:

				print("\nNo ha cargado ningun dia aun\n")

			else:
				comparar(min(newRestaurante.semana.vec))

		elif salir == 0:
			return


main()
