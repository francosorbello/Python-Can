from LinkedList import *


class Restaurante :
  semana = None
  Rotador = None
  
  
## TENDRIA QUE HACER UNA MATRIZ EN LA PRIMERA FILA LOS DIAS Y LA SEGUNDA FILA LA CANTIDAD DE PEDIDOS
  
class semana :
  vec = []
  
class Rotador:
  L = LinkedList()
  pedidos = None
 
  
class pedidos :
  def __init__(self):
    
    self.L = LinkedList()
  
  


salir = -1


def nuevo_pedido():## CARGO UN NUEVO PEDIDO
  salir = -1
  newpedido = pedidos()
  i = 0
  while salir != 0:
    pedi = input("Diga el plato")
    enqueue(newpedido.L , pedi) 
    print (newpedido.L.head.value)
    i = i + 1 
    salir = int(input("0 para salir \n 1 para cargar otro plato"))
  return newpedido
  
newRestaurante = Restaurante()
newRestaurante.semana = semana()
  

 

  

      
def new_dia():
  
  
  new_rotador = Rotador()
  salir = -1
  while salir != 0 :
    
    
    
    salir = int(input ("quiere salir ? , apriete 0 \n o 1 para nuevo pedido \no 2 para saber la cantidad de hoy dia \n 3. Siguiente plato "))
    
    if salir ==1 :
      pedidox = nuevo_pedido()
      add(new_rotador.L,pedidox)
      newRestaurante.Rotador = new_rotador
      
    elif salir== 2 :
      print("La cantidad de pedidos que lleva hoy dia es ", length(new_rotador.L))
    elif salir == 0 :
      newRestaurante.semana.vec.append(length(new_rotador.L))
      print (newRestaurante.semana.vec)
    elif salir == 3 :
      print("Plato actual: ",new_rotador.L.head.value.L.head.value)#muestra el plato actual
    elif salir == 4 :
      print(dequeue(new_rotador.L.head.value.head.)
    
def comparar(n):
  if n == 1 :
    print("lunes")  
  elif n == 2:
    print ("martes")
  elif n == 3:
    print ("miercoles")
  elif n == 4:
    print ("jueves")
  elif n == 5:
    print ("viernes")
  elif n == 6:
    print ("sabado")
  elif n == 7:
    print ("domingo")
    
def main ():
  salir = -1
  while salir != 0 :
    salir = int(input("Marque la opcion deseada\n 1.Nuevo dia\n 2.Consultar menor pedidos \n 0.salir del programa "))
    
    if salir == 1 :
      new_dia()
    elif salir == 2 :
     comparar(max(newRestaurante.semana.vec))
      
    elif salir == 0 :
      return
    
      
          
main()
     
  
    
    
    
    